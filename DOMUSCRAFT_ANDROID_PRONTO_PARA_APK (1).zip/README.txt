DOMUSCRAFT Android v0.1
Abrir esta pasta no Android Studio. Aguardar sincronizacao Gradle. Menu Build > Build Bundle(s) / APK(s) > Build APK(s). O APK sera gerado em app/build/outputs/apk/debug/app-debug.apk.
